"""
Script to load Kaggle Insurance Dataset using kagglehub and enrich it with
generated data to match our complete database schema
Outputs data to CSV files instead of database
"""
import kagglehub
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
import random

load_dotenv()

# Output directory for CSV files
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "output")

# Random seed for reproducibility
np.random.seed(42)
random.seed(42)

def download_dataset():
    """Download dataset using kagglehub"""
    print("Downloading dataset from Kaggle...")
    try:
        path = kagglehub.dataset_download("mirichoi0218/insurance")
        print(f"Dataset downloaded to: {path}")
        return path
    except Exception as e:
        print(f"Error downloading dataset: {e}")
        raise

def load_insurance_data(path):
    """Load insurance dataset from downloaded path"""
    # Find CSV file in the path
    csv_file = None
    for root, dirs, files in os.walk(path):
        for file in files:
            if file.endswith('.csv'):
                csv_file = os.path.join(root, file)
                break
        if csv_file:
            break
    
    if not csv_file:
        raise FileNotFoundError(f"No CSV file found in {path}")
    
    df = pd.read_csv(csv_file)
    print(f"Loaded {len(df)} records from {csv_file}")
    return df

def calculate_date_of_birth(age):
    """Calculate date of birth from age"""
    return datetime.now() - timedelta(days=int(age * 365.25))

def generate_height_weight_from_bmi(bmi, age, sex):
    """Generate realistic height and weight from BMI"""
    # Average heights by age and sex (in cm)
    if sex == 'male':
        base_height = 175 + (age - 30) * 0.1  # Slight decrease with age
        base_height = max(160, min(190, base_height))
    else:
        base_height = 162 + (age - 30) * 0.1
        base_height = max(150, min(180, base_height))
    
    # Add some variation
    height_cm = base_height + np.random.normal(0, 5)
    height_cm = max(140, min(210, height_cm))
    
    # Calculate weight from BMI and height
    height_m = height_cm / 100
    weight_kg = bmi * (height_m ** 2)
    weight_kg = max(40, min(200, weight_kg))
    
    return round(height_cm, 2), round(weight_kg, 2)

def generate_blood_pressure(age, bmi, smoker):
    """Generate realistic blood pressure based on age, BMI, and smoking"""
    # Base systolic BP increases with age
    base_systolic = 110 + (age - 18) * 0.5
    # Higher BMI increases BP
    base_systolic += (bmi - 25) * 0.8
    # Smoking increases BP
    if smoker == 'yes':
        base_systolic += 5
    
    systolic = base_systolic + np.random.normal(0, 8)
    systolic = max(90, min(180, int(systolic)))
    
    # Diastolic is typically 60-80% of systolic
    diastolic = systolic * 0.65 + np.random.normal(0, 5)
    diastolic = max(60, min(120, int(diastolic)))
    
    return systolic, diastolic

def generate_heart_rate(age, physical_activity):
    """Generate resting heart rate"""
    # Base heart rate decreases with age
    base_hr = 75 - (age - 18) * 0.1
    # Physical activity lowers resting HR
    if physical_activity in ['active', 'very_active']:
        base_hr -= 10
    elif physical_activity == 'moderate':
        base_hr -= 5
    
    hr = base_hr + np.random.normal(0, 5)
    hr = max(50, min(100, int(hr)))
    return hr

def generate_lab_results(age, sex, bmi, smoker, region):
    """Generate realistic laboratory results"""
    # Cholesterol - higher with age, BMI, smoking
    base_cholesterol = 180 + (age - 18) * 0.5 + (bmi - 25) * 2
    if smoker == 'yes':
        base_cholesterol += 15
    total_cholesterol = base_cholesterol + np.random.normal(0, 20)
    total_cholesterol = max(100, min(300, round(total_cholesterol, 2)))
    
    # LDL (bad cholesterol) - typically 60-70% of total
    ldl = total_cholesterol * 0.65 + np.random.normal(0, 15)
    ldl = max(50, min(250, round(ldl, 2)))
    
    # HDL (good cholesterol) - higher in women, lower with smoking
    base_hdl = 50 if sex == 'male' else 60
    if smoker == 'yes':
        base_hdl -= 5
    hdl = base_hdl + np.random.normal(0, 8)
    hdl = max(30, min(100, round(hdl, 2)))
    
    # Triglycerides - higher with BMI, smoking
    base_trig = 100 + (bmi - 25) * 5
    if smoker == 'yes':
        base_trig += 20
    triglycerides = base_trig + np.random.normal(0, 30)
    triglycerides = max(50, min(400, round(triglycerides, 2)))
    
    # Glucose - higher with age, BMI
    base_glucose = 85 + (age - 18) * 0.3 + (bmi - 25) * 0.5
    glucose = base_glucose + np.random.normal(0, 8)
    glucose = max(70, min(120, round(glucose, 2)))
    
    # HbA1c - correlates with glucose
    hba1c = (glucose + 46.7) / 28.7 + np.random.normal(0, 0.2)
    hba1c = max(4.0, min(6.5, round(hba1c, 2)))
    
    # Creatinine - higher in men, with age
    base_creatinine = 0.9 if sex == 'male' else 0.7
    base_creatinine += (age - 18) * 0.005
    creatinine = base_creatinine + np.random.normal(0, 0.1)
    creatinine = max(0.5, min(1.5, round(creatinine, 2)))
    
    # eGFR - decreases with age
    base_egfr = 120 - (age - 18) * 0.8
    egfr = base_egfr + np.random.normal(0, 10)
    egfr = max(60, min(120, round(egfr, 2)))
    
    return {
        'total_cholesterol': total_cholesterol,
        'ldl_cholesterol': ldl,
        'hdl_cholesterol': hdl,
        'triglycerides': triglycerides,
        'glucose': glucose,
        'hba1c': hba1c,
        'creatinine': creatinine,
        'egfr': egfr
    }

def generate_lifestyle_data(age, sex, bmi, smoker, children):
    """Generate additional lifestyle data"""
    # Physical activity - inversely related to BMI, age
    activity_levels = ['sedentary', 'light', 'moderate', 'active', 'very_active']
    if bmi > 30:
        weights = [0.4, 0.3, 0.2, 0.08, 0.02]  # More sedentary
    elif bmi > 25:
        weights = [0.2, 0.3, 0.3, 0.15, 0.05]
    else:
        weights = [0.1, 0.2, 0.3, 0.3, 0.1]  # More active
    
    physical_activity = np.random.choice(activity_levels, p=weights)
    
    # Exercise hours - based on activity level
    exercise_hours_map = {
        'sedentary': (0, 1),
        'light': (1, 3),
        'moderate': (3, 5),
        'active': (5, 8),
        'very_active': (8, 15)
    }
    min_hours, max_hours = exercise_hours_map[physical_activity]
    exercise_hours = round(np.random.uniform(min_hours, max_hours), 2)
    
    # Steps per day
    steps_map = {
        'sedentary': (2000, 5000),
        'light': (5000, 7000),
        'moderate': (7000, 10000),
        'active': (10000, 15000),
        'very_active': (15000, 25000)
    }
    min_steps, max_steps = steps_map[physical_activity]
    steps_per_day = int(np.random.uniform(min_steps, max_steps))
    
    # Alcohol consumption
    alcohol_levels = ['none', 'occasional', 'moderate', 'heavy']
    if smoker == 'yes':
        # Smokers more likely to drink
        weights = [0.2, 0.3, 0.4, 0.1]
    else:
        weights = [0.3, 0.4, 0.25, 0.05]
    alcohol_consumption = np.random.choice(alcohol_levels, p=weights)
    
    drinks_per_week = {
        'none': 0,
        'occasional': (1, 3),
        'moderate': (4, 7),
        'heavy': (8, 20)
    }
    if alcohol_consumption == 'none':
        drinks = 0
    else:
        min_drinks, max_drinks = drinks_per_week[alcohol_consumption]
        drinks = int(np.random.uniform(min_drinks, max_drinks))
    
    # Diet type
    diet_types = ['omnivore', 'vegetarian', 'vegan', 'pescatarian', 'mediterranean']
    weights = [0.7, 0.15, 0.05, 0.05, 0.05]
    diet_type = np.random.choice(diet_types, p=weights)
    
    # Sleep hours - 7-9 is normal, varies slightly
    sleep_hours = round(np.random.normal(7.5, 1.0), 1)
    sleep_hours = max(5, min(10, sleep_hours))
    
    # Sleep quality
    sleep_quality = np.random.choice(['poor', 'fair', 'good', 'excellent'], 
                                     p=[0.15, 0.25, 0.45, 0.15])
    
    # Smoking details if smoker
    if smoker == 'yes':
        years_smoking = max(1, age - 18 - np.random.randint(0, 5))
        cigarettes_per_day = int(np.random.uniform(5, 30))
        pack_years = round((cigarettes_per_day / 20) * years_smoking, 2)
    else:
        years_smoking = 0
        cigarettes_per_day = 0
        pack_years = 0.0
    
    return {
        'physical_activity_level': physical_activity,
        'exercise_hours_per_week': exercise_hours,
        'steps_per_day': steps_per_day,
        'alcohol_consumption': alcohol_consumption,
        'drinks_per_week': drinks,
        'diet_type': diet_type,
        'sleep_hours_per_night': sleep_hours,
        'sleep_quality': sleep_quality,
        'years_smoking': years_smoking,
        'cigarettes_per_day': cigarettes_per_day,
        'pack_years': pack_years
    }

def generate_socioeconomic_data(age, region, children):
    """Generate socioeconomic data"""
    # Employment status
    if age < 18:
        employment_status = 'student'
    elif age < 65:
        employment_status = np.random.choice(
            ['employed', 'unemployed', 'student'],
            p=[0.85, 0.1, 0.05]
        )
    else:
        employment_status = np.random.choice(
            ['retired', 'employed'],
            p=[0.9, 0.1]
        )
    
    # Education level
    education_levels = [
        'less_than_high_school', 'high_school', 'some_college',
        'bachelor', 'master', 'doctorate'
    ]
    if age < 25:
        weights = [0.1, 0.3, 0.4, 0.15, 0.04, 0.01]
    else:
        weights = [0.15, 0.25, 0.25, 0.25, 0.08, 0.02]
    education_level = np.random.choice(education_levels, p=weights)
    
    # Income - correlates with education and age
    income_base = {
        'less_than_high_school': 25000,
        'high_school': 35000,
        'some_college': 45000,
        'bachelor': 65000,
        'master': 85000,
        'doctorate': 120000
    }
    base_income = income_base[education_level]
    # Income increases with age (up to 50)
    if age < 50:
        age_multiplier = 1 + (age - 25) * 0.02
    else:
        age_multiplier = 1.5
    annual_income = base_income * age_multiplier * np.random.uniform(0.8, 1.3)
    annual_income = max(10000, round(annual_income, 2))
    
    # Housing type
    if annual_income > 50000:
        housing_weights = [0.7, 0.25, 0.05]  # More owned
    else:
        housing_weights = [0.3, 0.6, 0.1]  # More rented
    housing_type = np.random.choice(['owned', 'rented', 'other'], p=housing_weights)
    
    # Household size
    household_size = 1 + children + (1 if np.random.random() > 0.3 else 0)  # Partner
    household_size = max(1, min(8, household_size))
    
    # Insurance type
    if employment_status == 'employed':
        insurance_type = np.random.choice(
            ['employer', 'individual'],
            p=[0.8, 0.2]
        )
    else:
        insurance_type = np.random.choice(
            ['individual', 'medicare', 'medicaid', 'uninsured'],
            p=[0.3, 0.2, 0.3, 0.2]
        )
    
    # Insurance plan details
    if insurance_type != 'uninsured':
        plan_types = ['HMO', 'PPO', 'EPO', 'POS', 'HDHP']
        insurance_plan_type = np.random.choice(plan_types, p=[0.3, 0.4, 0.1, 0.1, 0.1])
        
        # Deductible based on plan type
        deductible_map = {
            'HMO': (500, 2000),
            'PPO': (1000, 5000),
            'EPO': (1000, 4000),
            'POS': (1500, 6000),
            'HDHP': (2000, 7000)
        }
        min_ded, max_ded = deductible_map[insurance_plan_type]
        deductible = round(np.random.uniform(min_ded, max_ded), 2)
        
        copay_amount = round(np.random.uniform(20, 50), 2)
        out_of_pocket_max = round(deductible * 2.5, 2)
    else:
        insurance_plan_type = None
        deductible = None
        copay_amount = None
        out_of_pocket_max = None
    
    # Residential area
    residential_area = np.random.choice(
        ['urban', 'suburban', 'rural'],
        p=[0.4, 0.45, 0.15]
    )
    
    return {
        'region': region,
        'employment_status': employment_status,
        'education_level': education_level,
        'annual_income': annual_income,
        'housing_type': housing_type,
        'household_size': household_size,
        'insurance_type': insurance_type,
        'insurance_plan_type': insurance_plan_type,
        'deductible': deductible,
        'copay_amount': copay_amount,
        'out_of_pocket_max': out_of_pocket_max,
        'residential_area': residential_area,
        'years_with_insurance': max(1, int(np.random.uniform(1, 20))),
        'coverage_gaps': int(np.random.exponential(0.5)),
        'total_days_without_insurance': int(np.random.exponential(30))
    }

def generate_medical_history(age, bmi, smoker):
    """Generate medical history based on risk factors"""
    conditions = []
    
    # Diabetes risk increases with age, BMI
    diabetes_risk = 0.01 + (age - 18) * 0.001 + (bmi - 25) * 0.01
    if np.random.random() < diabetes_risk:
        years = max(1, int(np.random.uniform(1, age - 18)))
        conditions.append({
            'condition_type': 'diabetes',
            'condition_name': 'Type 2 Diabetes',
            'severity': np.random.choice(['mild', 'moderate', 'severe'], p=[0.5, 0.4, 0.1]),
            'years_since_diagnosis': years,
            'medication_controlled': np.random.random() > 0.3
        })
    
    # Hypertension risk
    hypertension_risk = 0.05 + (age - 18) * 0.002 + (bmi - 25) * 0.01
    if smoker == 'yes':
        hypertension_risk += 0.1
    if np.random.random() < hypertension_risk:
        years = max(1, int(np.random.uniform(1, age - 18)))
        conditions.append({
            'condition_type': 'hypertension',
            'condition_name': 'Hypertension',
            'severity': np.random.choice(['mild', 'moderate'], p=[0.7, 0.3]),
            'years_since_diagnosis': years,
            'medication_controlled': np.random.random() > 0.2
        })
    
    # Heart disease (lower probability)
    heart_disease_risk = 0.01 + (age - 40) * 0.002 if age > 40 else 0.001
    if smoker == 'yes':
        heart_disease_risk *= 2
    if np.random.random() < heart_disease_risk:
        years = max(1, int(np.random.uniform(1, max(1, age - 40))))
        conditions.append({
            'condition_type': 'heart_disease',
            'condition_name': 'Coronary Artery Disease',
            'severity': np.random.choice(['mild', 'moderate', 'severe'], p=[0.6, 0.3, 0.1]),
            'years_since_diagnosis': years,
            'medication_controlled': np.random.random() > 0.4
        })
    
    return conditions

def transform_data(df):
    """Transform and enrich dataset"""
    print("\nTransforming and enriching data...")
    
    # Patients table
    patients = []
    physical_measurements = []
    lifestyle_records = []
    socioeconomic_records = []
    medical_history_records = []
    lab_results_records = []
    
    for idx, row in df.iterrows():
        age = int(row['age'])
        sex = row['sex'].lower()
        bmi = float(row['bmi'])
        smoker = row['smoker']
        children = int(row['children'])
        region = row['region'].lower()
        charges = float(row['charges'])
        
        # Generate additional data
        height_cm, weight_kg = generate_height_weight_from_bmi(bmi, age, sex)
        systolic_bp, diastolic_bp = generate_blood_pressure(age, bmi, smoker)
        heart_rate = generate_heart_rate(age, 'moderate')  # Will be updated with lifestyle
        lab_results = generate_lab_results(age, sex, bmi, smoker, region)
        lifestyle = generate_lifestyle_data(age, sex, bmi, smoker, children)
        socioeconomic = generate_socioeconomic_data(age, region, children)
        medical_history = generate_medical_history(age, bmi, smoker)
        
        # Update heart rate based on actual activity level
        heart_rate = generate_heart_rate(age, lifestyle['physical_activity_level'])
        
        # Patient record
        patients.append({
            'institution_id': 1,
            'created_by': 1,
            'first_name': 'Patient',
            'last_name': f"{idx + 1:04d}",
            'date_of_birth': calculate_date_of_birth(age),
            'sex': sex,
            'marital_status': 'single' if children == 0 else 'married',
            'number_of_dependents': children,
            'insurance_cost': charges,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        })
        
        # Physical measurements
        physical_measurements.append({
            'patient_id': idx + 1,  # Will be updated after insert
            'height_cm': height_cm,
            'weight_kg': weight_kg,
            'bmi': bmi,
            'body_fat_percentage': round(1.2 * bmi + 0.23 * age - 10.8 - 5.4 if sex == 'male' else 1.2 * bmi + 0.23 * age - 5.4, 2),
            'waist_circumference': round(0.5 * height_cm + np.random.normal(0, 5), 2),
            'hip_circumference': round(0.6 * height_cm + np.random.normal(0, 5), 2),
            'systolic_bp': systolic_bp,
            'diastolic_bp': diastolic_bp,
            'resting_heart_rate': heart_rate,
            'max_heart_rate': 220 - age,
            'measured_at': datetime.now(),
            'updated_at': datetime.now()
        })
        
        # Lifestyle
        lifestyle_records.append({
            'patient_id': idx + 1,
            'smoking_status': 'current' if smoker == 'yes' else 'never',
            'years_smoking': lifestyle['years_smoking'],
            'cigarettes_per_day': lifestyle['cigarettes_per_day'],
            'pack_years': lifestyle['pack_years'],
            'alcohol_consumption': lifestyle['alcohol_consumption'],
            'drinks_per_week': lifestyle['drinks_per_week'],
            'drinking_frequency': 'weekly' if lifestyle['drinks_per_week'] > 0 else 'never',
            'physical_activity_level': lifestyle['physical_activity_level'],
            'exercise_hours_per_week': lifestyle['exercise_hours_per_week'],
            'steps_per_day': lifestyle['steps_per_day'],
            'diet_type': lifestyle['diet_type'],
            'sleep_hours_per_night': lifestyle['sleep_hours_per_night'],
            'sleep_quality': lifestyle['sleep_quality'],
            'updated_at': datetime.now()
        })
        
        # Socioeconomic
        socioeconomic_records.append({
            'patient_id': idx + 1,
            **socioeconomic,
            'updated_at': datetime.now()
        })
        
        # Medical history
        for condition in medical_history:
            medical_history_records.append({
                'patient_id': idx + 1,
                **condition,
                'diagnosis_date': datetime.now() - timedelta(days=condition['years_since_diagnosis'] * 365),
                'created_at': datetime.now()
            })
        
        # Lab results
        lab_results_records.append({
            'patient_id': idx + 1,
            'test_date': datetime.now() - timedelta(days=np.random.randint(0, 365)),
            'test_type': 'comprehensive',
            **lab_results,
            'created_at': datetime.now()
        })
        
        if (idx + 1) % 100 == 0:
            print(f"  Processed {idx + 1}/{len(df)} records...")
    
    return (
        pd.DataFrame(patients),
        pd.DataFrame(physical_measurements),
        pd.DataFrame(lifestyle_records),
        pd.DataFrame(socioeconomic_records),
        pd.DataFrame(medical_history_records),
        pd.DataFrame(lab_results_records)
    )

def save_to_csv(patients_df, physical_df, lifestyle_df, 
                socioeconomic_df, medical_history_df, lab_results_df):
    """Save data to CSV files"""
    print("\nSaving data to CSV files...")
    
    # Create output directory if it doesn't exist
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Add patient IDs (sequential from 1)
    patient_ids = list(range(1, len(patients_df) + 1))
    
    # Update dataframes with patient IDs
    # Note: medical_history_df already has correct patient_id from transform_data
    # and may have fewer records than patients (not all patients have medical history)
    physical_df['patient_id'] = patient_ids
    lifestyle_df['patient_id'] = patient_ids
    socioeconomic_df['patient_id'] = patient_ids
    # medical_history_df already has correct patient_id, don't overwrite
    lab_results_df['patient_id'] = patient_ids
    
    # Save patients
    patients_file = os.path.join(OUTPUT_DIR, 'patients.csv')
    print(f"Saving {len(patients_df)} patients to {patients_file}...")
    patients_df.to_csv(patients_file, index=False)
    
    # Save physical measurements
    physical_file = os.path.join(OUTPUT_DIR, 'patient_physical_measurements.csv')
    print(f"Saving {len(physical_df)} physical measurements to {physical_file}...")
    physical_df.to_csv(physical_file, index=False)
    
    # Save lifestyle
    lifestyle_file = os.path.join(OUTPUT_DIR, 'patient_lifestyle.csv')
    print(f"Saving {len(lifestyle_df)} lifestyle records to {lifestyle_file}...")
    lifestyle_df.to_csv(lifestyle_file, index=False)
    
    # Save socioeconomic
    socioeconomic_file = os.path.join(OUTPUT_DIR, 'patient_socioeconomic.csv')
    print(f"Saving {len(socioeconomic_df)} socioeconomic records to {socioeconomic_file}...")
    socioeconomic_df.to_csv(socioeconomic_file, index=False)
    
    # Save medical history
    if len(medical_history_df) > 0:
        medical_history_file = os.path.join(OUTPUT_DIR, 'patient_medical_history.csv')
        print(f"Saving {len(medical_history_df)} medical history records to {medical_history_file}...")
        medical_history_df.to_csv(medical_history_file, index=False)
    
    # Save lab results
    lab_results_file = os.path.join(OUTPUT_DIR, 'patient_lab_results.csv')
    print(f"Saving {len(lab_results_df)} lab results to {lab_results_file}...")
    lab_results_df.to_csv(lab_results_file, index=False)
    
    print(f"\nAll data saved successfully to '{OUTPUT_DIR}' directory!")
    print(f"\nGenerated files:")
    print(f"  - {patients_file}")
    print(f"  - {physical_file}")
    print(f"  - {lifestyle_file}")
    print(f"  - {socioeconomic_file}")
    if len(medical_history_df) > 0:
        print(f"  - {medical_history_file}")
    print(f"  - {lab_results_file}")

def display_statistics(patients_df, physical_df, lifestyle_df, 
                       socioeconomic_df, medical_history_df, lab_results_df):
    """Display loading statistics"""
    print("\n" + "=" * 60)
    print("Data Loading Statistics")
    print("=" * 60)
    
    # Count patients
    patient_count = len(patients_df)
    print(f"\nTotal patients: {patient_count}")
    
    # Count by region
    if 'region' in socioeconomic_df.columns:
        region_counts = socioeconomic_df['region'].value_counts()
        print("\nPatients by region:")
        for region, count in region_counts.items():
            print(f"  {region}: {count}")
    
    # Count by smoking status
    if 'smoking_status' in lifestyle_df.columns:
        smoking_counts = lifestyle_df['smoking_status'].value_counts()
        print("\nPatients by smoking status:")
        for status, count in smoking_counts.items():
            print(f"  {status}: {count}")
    
    # Count by activity level
    if 'physical_activity_level' in lifestyle_df.columns:
        activity_counts = lifestyle_df['physical_activity_level'].value_counts()
        print("\nPatients by activity level:")
        for activity, count in activity_counts.items():
            print(f"  {activity}: {count}")
    
    # Medical conditions
    if len(medical_history_df) > 0 and 'condition_type' in medical_history_df.columns:
        condition_counts = medical_history_df['condition_type'].value_counts()
        print("\nMedical conditions:")
        for condition, count in condition_counts.items():
            print(f"  {condition}: {count}")
    
    # Insurance cost statistics
    if 'insurance_cost' in patients_df.columns:
        costs = patients_df['insurance_cost'].dropna()
        if len(costs) > 0:
            print("\nInsurance cost statistics:")
            print(f"  Average: ${costs.mean():,.2f}")
            print(f"  Median: ${costs.median():,.2f}")
            print(f"  Minimum: ${costs.min():,.2f}")
            print(f"  Maximum: ${costs.max():,.2f}")
            print(f"  Std Dev: ${costs.std():,.2f}")
    
    # Lab results summary
    if 'total_cholesterol' in lab_results_df.columns:
        chol = lab_results_df['total_cholesterol'].dropna()
        glucose = lab_results_df['glucose'].dropna()
        hba1c = lab_results_df['hba1c'].dropna()
        print("\nLab results averages:")
        if len(chol) > 0:
            print(f"  Total Cholesterol: {chol.mean():.2f} mg/dL")
        if len(glucose) > 0:
            print(f"  Glucose: {glucose.mean():.2f} mg/dL")
        if len(hba1c) > 0:
            print(f"  HbA1c: {hba1c.mean():.2f}%")

def main():
    """Main function"""
    print("=" * 60)
    print("Kaggle Insurance Dataset Loader with Data Enrichment")
    print("=" * 60)
    
    # Download dataset
    try:
        path = download_dataset()
    except Exception as e:
        print(f"Error: {e}")
        return
    
    # Load data
    try:
        df = load_insurance_data(path)
    except Exception as e:
        print(f"Error loading data: {e}")
        return
    
    # Display summary
    print(f"\nDataset Summary:")
    print(f"  Records: {len(df)}")
    print(f"  Features: {list(df.columns)}")
    print(f"\nSample data:")
    print(df.head())
    
    # Transform and enrich data
    try:
        (patients_df, physical_df, lifestyle_df, 
         socioeconomic_df, medical_history_df, lab_results_df) = transform_data(df)
    except Exception as e:
        print(f"Error transforming data: {e}")
        import traceback
        traceback.print_exc()
        return
    
    # Save data to CSV files
    try:
        save_to_csv(patients_df, physical_df, lifestyle_df, 
                   socioeconomic_df, medical_history_df, lab_results_df)
        display_statistics(patients_df, physical_df, lifestyle_df, 
                          socioeconomic_df, medical_history_df, lab_results_df)
    except Exception as e:
        print(f"\nError saving data: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

